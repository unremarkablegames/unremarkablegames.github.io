float beam_random(vec2 seed) {
    return fract(sin(dot(seed, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec2 local_uv = (v_tex_coord - a_beam_texture_rect.xy) / a_beam_texture_rect.zw;
    vec2 world_position = a_beam_canvas.xy + local_uv * a_beam_canvas.zw;
    float progress = clamp(a_beam_progress, 0.0, 1.0);
    vec4 output_color = vec4(0.0);

    if (progress < 0.95) {
        float pixel_width = a_beam_sprite.z / a_beam_sprite.x;
        float pixel_height = a_beam_sprite.w / a_beam_sprite.y;
        float rotated_pixel_width = abs(a_beam_rotation.x) * pixel_width
            + abs(a_beam_rotation.y) * pixel_height;
        float rotated_pixel_height = abs(a_beam_rotation.y) * pixel_width
            + abs(a_beam_rotation.x) * pixel_height;
        float solve_source_x = step(
            abs(a_beam_rotation.y) * pixel_height,
            abs(a_beam_rotation.x) * pixel_width
        );
        float total_pixels = a_beam_sprite.x * a_beam_sprite.y;
        float early_pixel_count = max(ceil(total_pixels * 0.25), 1.0);
        for (float variable_coordinate = 0.0; variable_coordinate < 16.0; variable_coordinate += 1.0) {
            float solved_coordinate;
            if (solve_source_x > 0.5) {
                float local_y = (
                    (variable_coordinate + 0.5) / a_beam_sprite.y - 0.5
                ) * a_beam_sprite.w;
                float local_x = (
                    world_position.x - a_beam_destination.x
                        + a_beam_rotation.y * local_y
                ) / a_beam_rotation.x;
                solved_coordinate = floor(
                    (local_x / a_beam_sprite.z + 0.5) * a_beam_sprite.x
                );
            } else {
                float local_x = (
                    (variable_coordinate + 0.5) / a_beam_sprite.x - 0.5
                ) * a_beam_sprite.z;
                float local_y = (
                    a_beam_rotation.x * local_x
                        - (world_position.x - a_beam_destination.x)
                ) / a_beam_rotation.y;
                solved_coordinate = floor(
                    (local_y / a_beam_sprite.w + 0.5) * a_beam_sprite.y
                );
            }
            for (float neighbor_offset = -1.0; neighbor_offset <= 1.0; neighbor_offset += 1.0) {
                vec2 source_pixel = solve_source_x > 0.5
                    ? vec2(solved_coordinate + neighbor_offset, variable_coordinate)
                    : vec2(variable_coordinate, solved_coordinate + neighbor_offset);
                if (source_pixel.x >= 0.0 && source_pixel.y >= 0.0
                    && source_pixel.x < a_beam_sprite.x
                    && source_pixel.y < a_beam_sprite.y) {
                    vec2 source_local = (
                        (source_pixel + vec2(0.5)) / a_beam_sprite.xy - vec2(0.5)
                    ) * a_beam_sprite.zw;
                    vec2 final_center = a_beam_destination + vec2(
                        source_local.x * a_beam_rotation.x - source_local.y * a_beam_rotation.y,
                        source_local.x * a_beam_rotation.y + source_local.y * a_beam_rotation.x
                    );
                    if (abs(world_position.x - final_center.x) <= rotated_pixel_width * 0.5) {
                        float linear_index = source_pixel.y * a_beam_sprite.x + source_pixel.x;
                        float rank = mod(linear_index * 73.0 + 19.0 + a_beam_seed, total_pixels);
                        float completion_progress;
                        if (total_pixels <= 1.0) {
                            completion_progress = 0.75;
                        } else if (rank < early_pixel_count) {
                            completion_progress = mix(
                                0.3,
                                0.5,
                                (rank + 1.0) / early_pixel_count
                            );
                        } else {
                            completion_progress = mix(
                                0.5001,
                                0.9,
                                (rank - early_pixel_count + 1.0) / (total_pixels - early_pixel_count)
                            );
                        }
                        float start_progress = beam_random(
                            vec2(rank, a_beam_seed + 7.0)
                        ) * 0.1;
                        if (progress >= start_progress) {
                            float stagger = beam_random(
                                vec2(linear_index + 31.0, a_beam_seed)
                            ) * a_beam_source.y;
                            float start_y = a_beam_source.x - stagger;
                            float travel_progress = clamp(
                                (progress - start_progress) / (completion_progress - start_progress),
                                0.0,
                                1.0
                            );
                            travel_progress = travel_progress * travel_progress
                                * (3.0 - 2.0 * travel_progress);
                            float current_y;
                            if (progress >= completion_progress) {
                                current_y = final_center.y;
                            } else {
                                float direction = sign(start_y - final_center.y);
                                if (direction == 0.0) {
                                    direction = 1.0;
                                }
                                float continuous_y = mix(
                                    start_y,
                                    final_center.y,
                                    travel_progress
                                );
                                float remaining_steps = max(
                                    ceil(
                                        abs(continuous_y - final_center.y)
                                            / rotated_pixel_height
                                    ),
                                    1.0
                                );
                                current_y = final_center.y
                                    + direction * remaining_steps * rotated_pixel_height;
                            }

                            vec2 moving_delta = world_position
                                - vec2(final_center.x, current_y);
                            vec2 moving_source_local = vec2(
                                moving_delta.x * a_beam_rotation.x
                                    + moving_delta.y * a_beam_rotation.y,
                                -moving_delta.x * a_beam_rotation.y
                                    + moving_delta.y * a_beam_rotation.x
                            );
                            float core = (
                                1.0 - step(pixel_width * 0.5, abs(moving_source_local.x))
                            ) * (
                                1.0 - step(pixel_height * 0.5, abs(moving_source_local.y))
                            );
                            float trail = 1.0 - step(
                                rotated_pixel_height * 3.5,
                                world_position.y - current_y
                            );
                            trail *= step(current_y, world_position.y);
                            trail *= 1.0 - step(
                                rotated_pixel_width * 0.5,
                                abs(world_position.x - final_center.x)
                            );
                            if (core > 0.0 || trail > 0.0) {
                                vec2 source_uv = (
                                    source_pixel + vec2(0.5)
                                ) / a_beam_sprite.xy;
                                vec4 source_color = texture2D(
                                    u_texture,
                                    a_beam_texture_rect.xy
                                        + source_uv * a_beam_texture_rect.zw
                                );
                                float unformed = 1.0
                                    - step(completion_progress, progress);
                                float visible_trail = trail * unformed;
                                vec3 energized = mix(
                                    source_color.rgb,
                                    vec3(0.35, 0.9, 1.0) * source_color.a,
                                    0.4 * unformed
                                );
                                float trail_alpha = source_color.a
                                    * visible_trail * 0.22;
                                vec4 pixel_color = vec4(
                                    energized * max(core, visible_trail * 0.45),
                                    max(source_color.a * core, trail_alpha)
                                );
                                output_color = pixel_color
                                    + output_color * (1.0 - pixel_color.a);
                            }
                        }
                    }
                }
            }
        }
    }

    gl_FragColor = output_color;
}
