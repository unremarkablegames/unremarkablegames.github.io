void main() {
    vec2 texel = 1.0 / a_crt_frame.xy;
    float transitionMode = a_crt_transition.x;
    float transitionFrame = floor(a_crt_transition.y + 0.5);
    float band = floor(v_tex_coord.y * 6.0);
    float noise = fract(
        sin(dot(vec2(band, transitionFrame), vec2(12.9898, 78.233)) + a_crt_transition.w)
            * 43758.5453
    );
    float entryTear = transitionFrame < 2.0
        ? 4.0
        : transitionFrame < 3.0
            ? 3.0
            : transitionFrame < 4.0
                ? 2.0
                : transitionFrame < 5.0 ? 1.0 : 0.0;
    float releaseTear = transitionFrame < 1.0
        ? 1.0
        : transitionFrame < 2.0 ? 2.0 : transitionFrame < 3.0 ? 4.0 : 0.0;
    float tearCells = transitionMode < 1.5 ? entryTear : releaseTear;
    float tearOffset = floor(noise * (tearCells * 2.0 + 1.0)) - tearCells;
    vec2 sampleCoordinate = v_tex_coord;
    if (transitionMode > 0.5) {
        sampleCoordinate.x = clamp(sampleCoordinate.x + tearOffset * texel.x, 0.0, 1.0);
    }
    vec4 color = texture2D(u_texture, sampleCoordinate);
    vec3 glow = vec3(0.0);
    glow += texture2D(u_texture, sampleCoordinate + vec2(1.5, 0.0) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(-1.5, 0.0) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(0.0, 1.5) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(0.0, -1.5) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(1.1, 1.1) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(-1.1, 1.1) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(1.1, -1.1) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(-1.1, -1.1) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(3.0, 0.0) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(-3.0, 0.0) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(0.0, 3.0) * texel).rgb;
    glow += texture2D(u_texture, sampleCoordinate + vec2(0.0, -3.0) * texel).rgb;
    color.rgb += glow * a_crt_effect.x;

    float scanlineDepth = a_crt_effect.y;
    float scanline = 1.0 - scanlineDepth
        + scanlineDepth * cos(v_tex_coord.y * a_crt_frame.y * 2.0943951);
    vec2 centered = v_tex_coord - 0.5;
    float vignette = clamp(
        1.0 - dot(centered, centered) * a_crt_effect.z,
        0.0,
        1.0
    );
    vec4 processed = vec4(color.rgb * scanline * vignette, color.a);
    if (transitionMode < 0.5) {
        gl_FragColor = processed;
    } else {
        float aperture;
        if (transitionMode < 1.5) {
            aperture = transitionFrame < 1.0
                ? 0.0
                : transitionFrame < 2.0
                    ? 0.08
                    : transitionFrame < 3.0
                        ? 0.28
                        : transitionFrame < 4.0
                            ? 0.55
                            : transitionFrame < 5.0 ? 0.82 : 1.0;
        } else {
            aperture = transitionFrame < 1.0
                ? 1.0
                : transitionFrame < 2.0 ? 0.65 : transitionFrame < 3.0 ? 0.25 : 0.0;
        }
        float centerDistance = abs(v_tex_coord.y - 0.5);
        float visible = aperture >= 1.0 ? 1.0 : 1.0 - step(aperture * 0.5, centerDistance);
        float traceWidth = max(texel.y, 0.002);
        float trace = 1.0 - step(traceWidth, centerDistance);
        vec2 signalCell = floor(v_tex_coord * a_crt_frame.xy);
        float signalNoise = fract(
            sin(dot(signalCell, vec2(91.3458, 47.2561)) + transitionFrame * 13.0 + a_crt_transition.w)
                * 47453.5453
        );
        float snow = step(0.992, signalNoise) * max(visible, trace);
        float pulseFrameCount = max(a_crt_transition.z, 2.0);
        float pulseProgress = transitionFrame / (pulseFrameCount - 1.0);
        if (transitionMode >= 1.5) {
            pulseProgress = 1.0 - pulseProgress;
        }
        float pulseHalfWidth = 4.0;
        float pulseTravel = max(
            a_crt_frame.x * 0.5 - pulseHalfWidth - 1.0,
            0.0
        ) * pulseProgress;
        vec2 logicalPosition = vec2(
            v_tex_coord.x * a_crt_frame.x,
            (v_tex_coord.y - 0.5) * a_crt_frame.y
        );
        float leftPulseCenter = a_crt_frame.x * 0.5 - pulseTravel;
        float rightPulseCenter = a_crt_frame.x * 0.5 + pulseTravel;
        float leftPulseHorizontal =
            (1.0 - step(pulseHalfWidth, abs(logicalPosition.x - leftPulseCenter)))
            * (1.0 - step(0.5, abs(logicalPosition.y - 2.0)));
        float rightPulseHorizontal =
            (1.0 - step(pulseHalfWidth, abs(logicalPosition.x - rightPulseCenter)))
            * (1.0 - step(0.5, abs(logicalPosition.y + 2.0)));
        float leftPulseConnectors =
            (1.0 - step(
                0.5,
                abs(abs(logicalPosition.x - leftPulseCenter) - pulseHalfWidth)
            ))
            * (1.0 - step(1.0, abs(logicalPosition.y - 1.0)));
        float rightPulseConnectors =
            (1.0 - step(
                0.5,
                abs(abs(logicalPosition.x - rightPulseCenter) - pulseHalfWidth)
            ))
            * (1.0 - step(1.0, abs(logicalPosition.y + 1.0)));
        float pulse = max(
            max(leftPulseHorizontal, rightPulseHorizontal),
            max(leftPulseConnectors, rightPulseConnectors)
        );
        vec3 transitionColor = processed.rgb * visible;
        transitionColor += vec3(0.2, 1.0, 0.2) * trace;
        transitionColor += vec3(snow * 0.12);
        transitionColor = max(transitionColor, vec3(0.8, 1.0, 0.8) * pulse);
        gl_FragColor = vec4(
            transitionColor,
            max(processed.a * visible, max(max(trace, snow), pulse))
        );
    }
}
