void main() {
    vec2 local_uv = clamp(
        (v_tex_coord - a_laser_texture_rect.xy) / a_laser_texture_rect.zw,
        vec2(0.0),
        vec2(0.999999)
    );
    vec2 local_pixel = floor(local_uv * 16.0);
    vec2 source_uv = a_laser_texture_rect.xy
        + ((local_pixel + vec2(0.5)) / 16.0) * a_laser_texture_rect.zw;
    vec4 base = texture2D(u_texture, source_uv);
    float vertical = step(0.5, a_laser_segment.z);
    float local_longitudinal_pixel = mix(
        local_pixel.x,
        15.0 - local_pixel.y,
        vertical
    );
    float longitudinal_pixel = a_laser_segment.x * 16.0
        + local_longitudinal_pixel;
    float cross_pixel = mix(local_pixel.y, local_pixel.x, vertical);
    float longitudinal_count = a_laser_segment.y * 16.0;
    float rail = mod(cross_pixel, 2.0);
    float mode = a_laser_presentation.x;
    float stage = a_laser_presentation.y;
    float visibility = 1.0;
    vec3 rgb = base.rgb;

    if (mode < 0.5) {
        float frame = floor(a_laser_time * 12.0);
        float phase = mod(
            longitudinal_pixel - frame + rail * 3.0 + a_laser_segment.w,
            8.0
        );
        vec3 head = vec3(1.0, 0.76, 1.0) * base.a;
        vec3 shoulder = vec3(1.0, 0.3, 0.78) * base.a;
        vec3 carrier = mix(
            base.rgb * 0.5,
            vec3(0.58, 0.02, 0.44) * base.a,
            0.35
        );
        if (phase < 1.0) {
            rgb = head;
        } else if (phase < 2.0) {
            rgb = mix(base.rgb, shoulder, 0.75) * 0.9;
        } else if (phase < 4.0) {
            rgb = base.rgb * 0.82;
        } else {
            rgb = carrier;
        }
        float flicker_frame = a_laser_presentation.z - 1.0;
        float flicker_active = step(0.0, flicker_frame);
        float flicker_sag = flicker_active * (
            1.0 - step(0.5, abs(flicker_frame - rail))
        );
        float flicker_rebound = flicker_active * (1.0 - step(
            0.5,
            abs(flicker_frame - (rail + 1.0))
        ));
        rgb *= mix(1.0, 0.6, flicker_sag);
        rgb = mix(rgb, head, flicker_rebound * 0.256);
    } else if (mode < 1.5) {
        if (stage < 0.5) {
            rgb = vec3(1.0, 0.82, 1.0) * base.a;
        } else {
            visibility = 1.0 - step(
                2.0,
                mod(longitudinal_pixel + rail * 2.0 + a_laser_segment.w, 4.0)
            );
            rgb = vec3(1.0, 0.24, 0.72) * base.a * 0.72;
        }
    } else if (mode < 2.5) {
        visibility = 0.0;
    } else {
        float progress = (stage + 1.0) / 6.0;
        float edge_distance = min(
            longitudinal_pixel,
            longitudinal_count - 1.0 - longitudinal_pixel
        );
        float rail_delay = rail * (1.0 - step(4.5, stage));
        float shifted_edge_distance = edge_distance + rail_delay;
        float front_reach = ceil(ceil(longitudinal_count * 0.5) * progress);
        float front = 1.0 - step(front_reach, shifted_edge_distance);
        float ghost = 1.0 - step(
            1.0,
            mod(longitudinal_pixel + rail * 3.0 + a_laser_segment.w, 8.0)
        );
        visibility = max(front, ghost);
        float front_edge = front * (
            1.0 - step(1.0, abs(shifted_edge_distance - (front_reach - 1.0)))
        );
        vec3 ghost_color = vec3(0.5, 0.01, 0.38) * base.a * 0.2;
        vec3 formed_color = base.rgb * mix(0.4, 0.86, progress);
        vec3 front_color = mix(
            formed_color,
            vec3(1.0, 0.68, 0.96) * base.a,
            front_edge * 0.72
        );
        rgb = mix(ghost_color, front_color, front);
    }

    float alpha = base.a * visibility;
    gl_FragColor = vec4(min(rgb * visibility, vec3(alpha)), alpha);
}
