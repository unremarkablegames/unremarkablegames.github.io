float breach_random(vec2 seed) {
    return fract(sin(dot(seed, vec2(12.9898, 78.233))) * 43758.5453);
}

vec2 breach_round(vec2 value) {
    return sign(value) * floor(abs(value) + vec2(0.5));
}

void main() {
    vec2 texture_origin = a_breach_texture_rect.xy;
    vec2 texture_size = a_breach_texture_rect.zw;
    vec2 proxy_uv = clamp(
        (v_tex_coord - texture_origin) / texture_size,
        vec2(0.0),
        vec2(0.999999)
    );
    vec2 canvas_pixel = floor(proxy_uv * 16.0);
    float frame = floor(clamp(a_breach_frame, 0.0, 7.0));
    vec2 direction = a_breach_direction;
    vec2 perpendicular = vec2(-direction.y, direction.x);
    vec2 impact_pixel = vec2(7.5) - direction * 7.0;
    vec2 base_sample_uv = texture_origin
        + ((canvas_pixel + vec2(0.5)) / 16.0) * texture_size;
    vec4 base_color = texture2D(u_texture, base_sample_uv);
    vec4 output_color = vec4(0.0);

    if (frame < 0.5) {
        float horizontal = step(abs(direction.y), abs(direction.x));
        vec2 split_axis = vec2(
            sign(direction.x) * horizontal,
            sign(direction.y) * (1.0 - horizontal)
        );
        vec2 forward_pixel = canvas_pixel + split_axis;
        vec2 backward_pixel = canvas_pixel - split_axis;
        float forward_valid = step(0.0, forward_pixel.x)
            * step(0.0, forward_pixel.y)
            * (1.0 - step(16.0, forward_pixel.x))
            * (1.0 - step(16.0, forward_pixel.y));
        float backward_valid = step(0.0, backward_pixel.x)
            * step(0.0, backward_pixel.y)
            * (1.0 - step(16.0, backward_pixel.x))
            * (1.0 - step(16.0, backward_pixel.y));
        vec4 forward_color = texture2D(
            u_texture,
            texture_origin
                + ((clamp(forward_pixel, vec2(0.0), vec2(15.0)) + vec2(0.5)) / 16.0)
                    * texture_size
        ) * forward_valid;
        vec4 backward_color = texture2D(
            u_texture,
            texture_origin
                + ((clamp(backward_pixel, vec2(0.0), vec2(15.0)) + vec2(0.5)) / 16.0)
                    * texture_size
        ) * backward_valid;
        vec4 split_color = vec4(
            forward_color.r,
            base_color.g,
            backward_color.b,
            max(base_color.a, max(forward_color.a, backward_color.a))
        );
        float impact_distance = length(canvas_pixel - impact_pixel);
        float impact_core = 1.0 - step(2.0, impact_distance);
        float impact_halo = 1.0 - step(4.25, impact_distance);
        vec3 separated = mix(base_color.rgb, split_color.rgb, impact_halo * 0.72);
        vec3 flash = vec3(0.76, 0.9, 0.92) * base_color.a;
        output_color = vec4(
            mix(separated, flash, impact_core * 0.58 + impact_halo * 0.1),
            base_color.a
        );
    } else if (frame < 6.5) {
        vec2 cluster = floor(canvas_pixel / 2.0);
        vec2 cluster_center = cluster * 2.0 + vec2(1.0);
        float travel_span = 14.0 * (abs(direction.x) + abs(direction.y));
        float projected_distance = dot(cluster_center - impact_pixel, direction);
        float distance_rank = clamp(projected_distance / travel_span, 0.0, 1.0);
        float breakup = breach_random(
            cluster + vec2(a_breach_seed, a_breach_seed * 0.37)
        ) * 0.18 - 0.09;
        float cluster_rank = clamp(distance_rank + breakup, 0.0, 1.0);
        float dissolve_threshold = (frame - 0.5) / 5.0;
        float visible = step(dissolve_threshold, cluster_rank);
        float energized_edge = visible
            * (1.0 - step(dissolve_threshold + 0.14, cluster_rank));
        float band = floor(canvas_pixel.y * 5.0 / 16.0);
        float band_shift = floor(
            breach_random(vec2(band + a_breach_seed, frame + 17.0)) * 3.0
        ) - 1.0;
        vec2 source_pixel = canvas_pixel
            - breach_round(perpendicular * band_shift * energized_edge);
        float source_valid = step(0.0, source_pixel.x)
            * step(0.0, source_pixel.y)
            * (1.0 - step(16.0, source_pixel.x))
            * (1.0 - step(16.0, source_pixel.y));
        vec4 body = texture2D(
            u_texture,
            texture_origin
                + ((clamp(source_pixel, vec2(0.0), vec2(15.0)) + vec2(0.5)) / 16.0)
                    * texture_size
        ) * source_valid;
        vec3 energized = mix(
            body.rgb,
            vec3(0.48, 0.78, 0.82) * body.a,
            energized_edge * 0.48
        );
        output_color = vec4(energized * visible, body.a * visible);
    }

    if (frame >= 1.5) {
        float travel_progress = (frame - 1.0) / 6.0;
        for (float mote_index = 0.0; mote_index < 3.0; mote_index += 1.0) {
            float mote_seed = a_breach_seed + mote_index * 29.0;
            float spread = floor(
                breach_random(vec2(mote_seed, 23.0)) * 9.0
            ) - 4.0;
            float depth = breach_random(vec2(mote_seed, 31.0)) * 8.0;
            float travel = 2.0 + breach_random(vec2(mote_seed, 19.0)) * 4.0;
            vec2 mote_origin = impact_pixel + perpendicular * spread + direction * depth;
            vec2 mote_pixel = breach_round(
                mote_origin
                    + direction * travel * travel_progress
                    + perpendicular * sin((frame + mote_index) * 1.7)
            );
            vec2 mote_delta = abs(canvas_pixel - mote_pixel);
            float mote_inside = (1.0 - step(0.5, mote_delta.x))
                * (1.0 - step(0.5, mote_delta.y));
            float late_survivor = 1.0 - step(0.5, mote_index);
            float mote_alive = max(1.0 - step(6.5, frame), late_survivor);
            float mote_alpha = mote_inside * mote_alive;
            vec4 mote_color = vec4(0.56, 0.82, 0.86, 1.0) * mote_alpha;
            output_color = mote_color + output_color * (1.0 - mote_color.a);
        }
    }

    gl_FragColor = output_color;
}
