float preview_rand(vec2 seed) {
    return fract(sin(dot(seed, vec2(12.9898, 78.233))) * 43758.5453);
}

float preview_grain(vec2 pixel, float frame, float seed) {
    vec3 value = fract(
        vec3(pixel, frame + seed) * vec3(0.1031, 0.1030, 0.0973)
    );
    value += dot(value, value.yzx + 33.33);
    return fract((value.x + value.y) * value.z);
}

void main() {
    float progress = clamp(a_reset_progress, 0.0, 1.0);
    vec2 texel = a_source_texel_size;
    float frame = floor(a_reset_frame);
    float band = floor(v_tex_coord.y * 12.0);
    float band_gate = step(0.42, preview_rand(vec2(band + a_fixed_seed, frame)));
    float tear = (preview_rand(vec2(frame + a_fixed_seed, band)) - 0.5) * 6.0 * texel.x * band_gate;
    float wobble = sin(v_tex_coord.y * 45.0 + frame * 0.73 + a_fixed_seed) * 2.0 * texel.x;
    vec2 displaced = v_tex_coord + vec2((tear + wobble) * progress, 0.0);
    vec2 minimum_uv = texel * 4.0;
    vec2 maximum_uv = vec2(1.0) - minimum_uv;
    displaced = clamp(displaced, minimum_uv, maximum_uv);

    float split = 2.0 * texel.x * progress;
    vec4 center = texture2D(u_texture, displaced);
    vec4 left = texture2D(u_texture, clamp(displaced - vec2(split, 0.0), minimum_uv, maximum_uv));
    vec4 right = texture2D(u_texture, clamp(displaced + vec2(split, 0.0), minimum_uv, maximum_uv));
    vec3 torn = vec3(right.r, center.g, left.b);

    float noise = preview_grain(
        floor(v_tex_coord / texel),
        frame,
        a_fixed_seed
    );
    float static_strength = progress * (0.22 + 0.38 * step(0.68, progress));
    vec3 preview_static_tint = vec3(0.2, 1.0, 0.2);
    vec3 noisy = mix(torn, preview_static_tint * noise * center.a, static_strength);
    float scanline = 0.78 + 0.22 * step(0.5, fract(v_tex_coord.y / texel.y * 0.5));
    float flicker = 0.84 + 0.16 * preview_rand(vec2(frame, a_fixed_seed + 19.0));
    vec3 rgb = noisy * mix(1.0, scanline * flicker, progress);
    gl_FragColor = vec4(rgb, center.a);
}
