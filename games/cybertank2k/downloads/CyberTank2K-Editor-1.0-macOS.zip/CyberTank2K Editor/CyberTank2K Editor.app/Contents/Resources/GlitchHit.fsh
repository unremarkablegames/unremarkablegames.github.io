float glitch_rand(vec2 seed) {
    return fract(sin(dot(seed, vec2(12.9898, 78.233))) * 43758.5453);
}

void main() {
    vec2 texture_origin = a_texture_rect.xy;
    vec2 texture_size = a_texture_rect.zw;
    vec2 local_uv = (v_tex_coord - texture_origin) / texture_size;
    float band = floor(local_uv.y * 6.0);

    float gate = step(0.45, glitch_rand(vec2(band, a_glitch_frame)));
    float shift = (glitch_rand(vec2(a_glitch_frame, band)) - 0.5) * 0.6 * gate;
    vec2 uv = vec2(fract(local_uv.x + shift), local_uv.y);

    float split = 0.03 + 0.08 * gate;
    vec2 base_uv = texture_origin + uv * texture_size;
    vec2 left_uv = texture_origin + vec2(fract(uv.x - split), uv.y) * texture_size;
    vec2 right_uv = texture_origin + vec2(fract(uv.x + split), uv.y) * texture_size;
    vec4 base = texture2D(u_texture, base_uv);
    vec4 left = texture2D(u_texture, left_uv);
    vec4 right = texture2D(u_texture, right_uv);

    vec3 rgb = vec3(right.r, base.g, left.b);
    float flicker = 0.8 + 0.4 * glitch_rand(vec2(a_glitch_frame, 3.7));
    float alpha = max(base.a, max(left.a, right.a));
    gl_FragColor = vec4(rgb * flicker, alpha);
}
